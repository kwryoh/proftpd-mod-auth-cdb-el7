/*
 * ProFTPD: mod_auth_cdb -- CDB authentication module, using Dan J. Bernstein's
 *                          CDB (Constant DataBase) format
 *
 * Copyright (c) 2001-2010 TJ Saunders
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 * As a special exemption, TJ Saunders gives permission to link this program
 * with OpenSSL, and distribute the resulting executable, without including
 * the source code for OpenSSL in the source distribution.
 *
 * This is mod_auth_cdb, contrib software for proftpd 1.2.x and above.
 * For more information contact TJ Saunders <tj@castaglia.org>.
 *
 * -- DO NOT MODIFY THE LINES BELOW --
 *
 * $Id: mod_auth_cdb.c,v 1.15 2010/11/18 18:56:50 tj Exp tj $
 */

#define MOD_AUTH_CDB_VERSION "mod_auth_cdb/0.9.1"

#include "conf.h"

/* Make sure the version of proftpd is as necessary. */
#if PROFTPD_VERSION_NUMBER < 0x0001030205
# error "ProFTPD 1.3.2 or later required"
#endif

#include <sys/mman.h>
#include <sys/types.h>

#if defined(HAVE_CRYPT_H) && !defined(AIX4) && !defined(AIX5)
# include <crypt.h>
#endif

module auth_cdb_module;

/* cdb defines.  Note that much of the CDB code is from Dan J. Bernstein's
 * code -- the credit for authorship goes to him.
 */

#define CDB_HASHSTART 5381

struct cdb {
  char *map;
  int fd;
  time_t mtime;
  unsigned long size;
  unsigned long loop;
  unsigned long khash;
  unsigned long kpos;
  unsigned long hpos;
  unsigned long hslots;
  unsigned long dpos;
  unsigned long dlen;
};

#define cdb_datapos(c) ((c)->dpos)
#define cdb_datalen(c) ((c)->dlen)

typedef enum {
  PR_CDB_GROUP,
  PR_CDB_PASSWD
} pr_cdb_type_t;

/* necessary cdb routine prototypes */
static void cdb_copy_data(register char *, register unsigned int,
  register char *);
static int cdb_diff_data(register char *, register unsigned int,
  register char *);
static unsigned cdb_free(struct cdb *);
static int cdb_has_key(struct cdb *, char *, unsigned int);
static unsigned long cdb_hash(char *, unsigned int);
static unsigned cdb_init(struct cdb *, int, pr_cdb_type_t);
static int cdb_match_key(struct cdb *, char *, unsigned int, unsigned long);
static int cdb_read(struct cdb *, char *, unsigned int, unsigned long);
static void cdb_rewind(struct cdb *);

/* module variables */

/* NOTE: use mlock() to protect static cache structures in future */

static char *authcdbgroupfile = NULL;
static struct cdb group_cdb;
static struct group group_cache;
static pool *group_pool = NULL;

static char *authcdbuserfile = NULL;
static struct cdb passwd_cdb;
static struct passwd passwd_cache;
static pool *passwd_pool = NULL;

static void cdb_clear_group_cache(void);
static void cdb_clear_passwd_cache(void);

#define PR_CDB_BUFFER_SIZE 80

/* CDB routines, so that this module does not require an external CDB library.
 * Incorporating the cdb code this way is the approach recommended in the
 * cdb sources themselves.
 */
static void cdb_copy_data(register char *to, register unsigned int len,
    register char *from) {

  for (;;) {
    if (!len)
      return;
    *to++ = *from++;
    --len;

    if (!len)
      return;
    *to++ = *from++;
    --len;

    if (!len)
      return;
    *to++ = *from++;
    --len;

    if (!len)
      return;
    *to++ = *from++;
    --len;
  }
}

static int cdb_diff_data(register char *s, register unsigned int len,
    register char *t) {

  for (;;) {
    if (!len)
      return 0;

    if (*s != *t)
      break;
    ++s; ++t; --len;

    if (!len)
      return 0;
 
    if (*s != *t)
      break;
    ++s; ++t; --len;

    if (!len)
      return 0;

    if (*s != *t)
      break;
    ++s; ++t; --len;

    if (!len)
      return 0;

    if (*s != *t)
      break;
    ++s; ++t; --len;
  }

  return ((int)(unsigned int)(unsigned char) *s)
       - ((int)(unsigned int)(unsigned char) *t);
}

static void cdb_unpack_data(char str[4], unsigned long *val) {
  unsigned long res;

  res = (unsigned char) str[3];
  res <<= 8;
  res += (unsigned char) str[2];
  res <<= 8;
  res += (unsigned char) str[1];
  res <<= 8;
  res += (unsigned char) str[0];

  *val = res;
}

static unsigned long cdb_hash(char *buf, unsigned int buflen) {
  unsigned long hash = CDB_HASHSTART;

  while (buflen) {
    hash += (hash << 5);
    hash = (hash ^ *buf++);
    --buflen;
  }

  return hash;
}

static int cdb_match_key(struct cdb *cdb, char *key, unsigned int len,
    unsigned long pos) {
  char buf[32] = {'\0'};
  unsigned int buflen;

  while (len > 0) {
    buflen = sizeof(buf);
    if (buflen > len)
      buflen = len;

    if (cdb_read(cdb, buf, buflen, pos) == -1)
      return -1;

    if (cdb_diff_data(buf, buflen, key))
      return 0;

    pos += buflen;
    key += buflen;
    len -= buflen;
  }

  return 1;
}

static void cdb_rewind(struct cdb *cdb) {
  cdb->loop = 0;
}

static unsigned int cdb_free(struct cdb *cdb) {
  if (cdb->map) {
    if (munmap(cdb->map, cdb->size) < 0)
      return FALSE;

    cdb->map = 0;
  }
  close(cdb->fd);
  cdb->fd = -1;

  return TRUE;
}

static unsigned int cdb_init(struct cdb *cdb, int fd, pr_cdb_type_t cdb_type) {
  struct stat sbuf;
  char *map = NULL;

  cdb_free(cdb);
  cdb_rewind(cdb);
  cdb->fd = fd;

  if (fstat(fd, &sbuf) == 0) {
    if (sbuf.st_size <= 0xffffffff) {
      if ((map = mmap(0, sbuf.st_size, PROT_READ, MAP_SHARED, fd, 0)) ==
          MAP_FAILED) {
        return FALSE;
      }

      if (map + 1) {
        cdb->size = sbuf.st_size;
        cdb->map = map;
      }

      /* make sure that if the modification time has changed for this
       * cdb, the cache for the appropiate information is cleared
       */
      if (sbuf.st_mtime > cdb->mtime) {
        if (cdb_type == PR_CDB_GROUP)
          cdb_clear_group_cache();
        if (cdb_type == PR_CDB_PASSWD)
          cdb_clear_passwd_cache();

        cdb->mtime = sbuf.st_mtime;
      }
    }
  }

  return TRUE;
}

static int cdb_read(struct cdb *cdb, char *buf, unsigned int buflen,
    unsigned long pos) {

  if (cdb->map) {
    if ((pos > cdb->size) || (cdb->size - pos < buflen)) {
      errno = EINTR;
      return -1;
    }

    cdb_copy_data(buf, buflen, cdb->map + pos);

  } else {

    if (lseek(cdb->fd, (off_t) pos, SEEK_SET) == -1)
      return -1;

    while (buflen > 0) {
      int res;

      /* read data */
      do {
        res = read(cdb->fd, buf, buflen);
      } while ((res == -1) && (errno == EINTR));

      if (res == -1)
        return -1;

      if (res == 0) {
        errno = EPROTO;
        return -1;
      }

      buf += res;
      buflen -= res;
    }
  }

  /* done */
  return 0;
}

static int cdb_has_key(struct cdb *cdb, char *key, unsigned int len) {
  char buf[8];
  unsigned long pos;
  unsigned long h;

  cdb_rewind(cdb);

  if (!cdb->loop) {
    h = cdb_hash(key, len);

    if (cdb_read(cdb, buf, 8, (h << 3) & 2047) == -1)
      return -1;
    cdb_unpack_data(buf + 4, &cdb->hslots);

    if (!cdb->hslots)
      return 0;
    cdb_unpack_data(buf, &cdb->hpos);

    cdb->khash = h;
    h >>= 8;
    h %= cdb->hslots;
    h <<= 3;
    cdb->kpos = cdb->hpos + h;
  }

  while (cdb->loop < cdb->hslots) {
    if (cdb_read(cdb, buf, 8, cdb->kpos) == -1)
      return -1;
    cdb_unpack_data(buf + 4, &pos);

    if (!pos)
      return 0;

    cdb->loop += 1;
    cdb->kpos += 8;

    if (cdb->kpos == cdb->hpos + (cdb->hslots << 3))
      cdb->kpos = cdb->hpos;
    cdb_unpack_data(buf, &h);

    if (h == cdb->khash) {
      if (cdb_read(cdb, buf, 8, pos) == -1)
        return -1;
      cdb_unpack_data(buf, &h);

      if (h == len) {
        switch(cdb_match_key(cdb, key, len, pos + 8)) {
          case -1:
            return -1;

          case 1:
            cdb_unpack_data(buf + 4, &cdb->dlen);
            cdb->dpos = pos + 8 + len;
            return 1;
        }
      }
    }
  }

  return 0;
}

/* Utility routines
 */

static array_header *cdb_get_tokens(pool *p, char *string, const char delim) {
  array_header *tokens = NULL;
  char *copystring = NULL, *substring = NULL;

  copystring = pstrdup(p, string);
  tokens = make_array(p, 0, sizeof(char *));

  /* break the given string up according to the delimiter, copying each
   * token into the array_header
   */
  substring = strchr(copystring, (int) delim);
  while (substring != NULL) {
    copystring[substring - copystring] = '\0';
    *((char **) push_array(tokens)) = pstrdup(p, copystring);

    copystring = ++substring;
    substring = strchr(copystring, (int) delim);
  }

  /* add the remaining substring to the tokens array, if any remain
   */
  if (*copystring != '\0')
    *((char **) push_array(tokens)) = pstrdup(p, copystring);

  return tokens;
}

static unsigned int cdb_close_group(void) {
  if (!cdb_free(&group_cdb))
    return FALSE;

  return TRUE;
}

static unsigned int cdb_open_group(void) {
  int cdb_fd = -1;

  if (group_cdb.fd != -1)
    return TRUE;

  authcdbgroupfile = get_param_ptr(main_server->conf, "AuthCDBGroupFile",
    FALSE);
  if (authcdbgroupfile == NULL)
    return FALSE;

  /* open the cdb file */
  cdb_fd = open(authcdbgroupfile, O_RDONLY);
  if (cdb_fd < 0) {
    pr_log_pri(PR_LOG_ERR, MOD_AUTH_CDB_VERSION ": unable to open '%s': %s",
      authcdbgroupfile, strerror(errno));
    return FALSE;
  }

  /* initialize the cdb struct */
  if (!cdb_init(&group_cdb, cdb_fd, PR_CDB_GROUP)) {
    pr_log_pri(PR_LOG_WARNING, MOD_AUTH_CDB_VERSION
      ": unable to initialize cdb struct: %s", strerror(errno));
    return FALSE; 
  }

  return TRUE;
}

static unsigned int cdb_close_passwd(void) {
  if (!cdb_free(&passwd_cdb))
    return FALSE;

  return TRUE;
}

static unsigned int cdb_open_passwd(void) {
  int cdb_fd = -1;

  if (passwd_cdb.fd != -1)
    return TRUE;

  authcdbuserfile = get_param_ptr(main_server->conf, "AuthCDBUserFile", FALSE);
  if (authcdbuserfile == NULL)
    return FALSE;

  /* open the cdb file */
  cdb_fd = open(authcdbuserfile, O_RDONLY);
  if (cdb_fd < 0) {
    pr_log_pri(PR_LOG_ERR, MOD_AUTH_CDB_VERSION ": unable to open '%s': %s",
      authcdbuserfile, strerror(errno));
    return FALSE;
  }

  /* initialize the cdb struct */
  if (!cdb_init(&passwd_cdb, cdb_fd, PR_CDB_PASSWD)) {
    pr_log_pri(PR_LOG_WARNING, MOD_AUTH_CDB_VERSION
      ": unable to initialize cdb struct: %s", strerror(errno));
    return FALSE;
  }

  return TRUE;
}

static int cdb_parse_group_value(char *value) {
  array_header *group_arr = NULL;
  char **group_tokens = NULL;

  /* clear the group cache */
  memset((void *) &group_cache, 0, sizeof(struct group));

  /* clear the group pool, and allocate a new one */
  destroy_pool(group_pool);
  group_pool = make_named_sub_pool(permanent_pool, "auth_cdb group pool");

  /* tokenize the given value, using the specified delimited */
  group_arr = cdb_get_tokens(group_pool, value, ':');

  /* sanity check: 3 is the minimum number of fields in a properly formatted
   * group(5) entry
   */
  if (group_arr->nelts < 3)
    return -1;

  group_tokens = (char **) group_arr->elts;

  /* copy the tokenized fields into group cache */
  group_cache.gr_name = group_tokens[0];
  group_cache.gr_passwd = group_tokens[1];
  group_cache.gr_gid = atol(group_tokens[2]);

  /* tokenize the fourth element, if present, using a different delimiter,
   * as it will be the comma-delimited list of users in this group.
   */
  if (group_arr->nelts >= 4) {
    register int index = 0;
    array_header *member_arr = cdb_get_tokens(group_pool, group_tokens[3], ',');
    char **member_tokens = (char **) member_arr->elts;

    group_cache.gr_mem = (char **) palloc(group_pool,
      member_arr->nelts * sizeof(char *));

    for (index = 0; index < member_arr->nelts; index++)
      group_cache.gr_mem[index] = member_tokens[index];

  } else {
    group_cache.gr_mem = NULL;
  }

  return 0;
}

static struct group *cdb_get_group(char *key) {
  char *group_entry = NULL;

  /* sanity check */
  if (group_cdb.fd == -1)
    return NULL;

  /* check to see if the requested group is in the cdb */
  if (cdb_has_key(&group_cdb, key, strlen(key)) <= 0) {
    char *groupstr = NULL;
    gid_t gid = -1;

    gid = (gid_t) strtol(key, &groupstr, 10);

    if (groupstr &&
        *groupstr != '\0') {
      pr_log_pri(PR_LOG_NOTICE, MOD_AUTH_CDB_VERSION
        ": no such group '%s' in '%s'", key, authcdbgroupfile);

    } else {
      pr_log_pri(PR_LOG_NOTICE, MOD_AUTH_CDB_VERSION
        ": no such GID '%lu' in '%s'", (unsigned long) gid, authcdbgroupfile);
    }

    return NULL;
  }

  /* read in the group data, parse it into the group cache, and return a
   * pointer to the cache
   */
  group_entry = (char *) pcalloc(group_pool, cdb_datalen(&group_cdb));

  if (cdb_read(&group_cdb, group_entry, cdb_datalen(&group_cdb),
      cdb_datapos(&group_cdb)) < 0) {
    pr_log_pri(PR_LOG_ERR, MOD_AUTH_CDB_VERSION ": error reading from '%s': %s",
      authcdbgroupfile, strerror(errno));
    return NULL;
  }

  if (cdb_parse_group_value(group_entry) < 0) {
    pr_log_pri(PR_LOG_ERR, MOD_AUTH_CDB_VERSION
      ": error parsing '%s' group entry in '%s': %s", key, authcdbgroupfile,
      strerror(EINVAL));
    return NULL;
  }

  return &group_cache;
}

static int cdb_parse_passwd_value(char *value) {
  array_header *passwd_arr = NULL;
  char **passwd_tokens = NULL;

  /* clear the passwd cache */
  memset((void *) &passwd_cache, 0, sizeof(struct passwd));

  /* clear the passwd pool, and reallocate a new one */
  destroy_pool(passwd_pool);
  passwd_pool = make_named_sub_pool(permanent_pool, "auth_cdb passwd pool");

  /* tokenize the given value, using the specified delimiter */
  passwd_arr = cdb_get_tokens(passwd_pool, value, ':');

  /* sanity check: 7 is the number of fields in a properly formatted
   * passwd(5) entry
   */
  if (passwd_arr->nelts < 7)
    return -1;

  passwd_tokens = (char **) passwd_arr->elts;

  /* copy the tokenized fields into the passwd cache */

  passwd_cache.pw_name = passwd_tokens[0];
  passwd_cache.pw_passwd = passwd_tokens[1];
  passwd_cache.pw_uid = atol(passwd_tokens[2]);
  passwd_cache.pw_gid = atol(passwd_tokens[3]);
  passwd_cache.pw_gecos = passwd_tokens[4];
  passwd_cache.pw_dir = passwd_tokens[5];
  passwd_cache.pw_shell = passwd_tokens[6];

  return 0; 
}

static struct passwd *cdb_get_passwd(char *key) {
  char *passwd_entry = NULL;
  int res;

  /* sanity check */
  if (passwd_cdb.fd == -1)
    return NULL;

  /* check to see if the requested passwd is in the cdb */
  res = cdb_has_key(&passwd_cdb, key, strlen(key));
  if (res == 0) {
    char *userstr = NULL;
    uid_t uid = -1;

    uid = (uid_t) strtol(key, &userstr, 10);

    if (userstr &&
        *userstr != '\0') {
      pr_log_pri(PR_LOG_NOTICE, MOD_AUTH_CDB_VERSION
        ": no such user '%s' in '%s'", key, authcdbuserfile);

    } else {
      pr_log_pri(PR_LOG_NOTICE, MOD_AUTH_CDB_VERSION
        ": no such UID '%lu' in '%s'", (unsigned long) uid, authcdbuserfile);
    }

    return NULL;

  } else if (res == -1) {
    pr_log_pri(PR_LOG_ERR, MOD_AUTH_CDB_VERSION ": error reading '%s': %s",
      authcdbuserfile, strerror(errno));
    return NULL;
  }

  /* read in the passwd data, parse it into the passwd cache, and return a
   * pointer to the cache
   */
  passwd_entry = (char *) pcalloc(passwd_pool, cdb_datalen(&passwd_cdb));

  if (cdb_read(&passwd_cdb, passwd_entry, cdb_datalen(&passwd_cdb),
      cdb_datapos(&passwd_cdb)) < 0) {
    pr_log_pri(PR_LOG_ERR, MOD_AUTH_CDB_VERSION ": error reading from '%s': %s",
      authcdbuserfile, strerror(errno));
    return NULL;
  }

  if (cdb_parse_passwd_value(passwd_entry) < 0) {
    pr_log_pri(PR_LOG_ERR, MOD_AUTH_CDB_VERSION
      ": error parsing '%s' passwd entry from '%s': %s", key, authcdbuserfile,
      strerror(EINVAL));
    return NULL;
  }

  return &passwd_cache;
}

static void cdb_clear_group_cache(void) {
  group_cache.gr_name = NULL;
  group_cache.gr_passwd = NULL;
  group_cache.gr_gid = (gid_t) -1;
  group_cache.gr_mem = NULL;
}

static void cdb_clear_passwd_cache(void) {
  passwd_cache.pw_name = NULL;
  passwd_cache.pw_passwd = NULL;
  passwd_cache.pw_uid = (uid_t) -1;
  passwd_cache.pw_gid = (gid_t) -1;
  passwd_cache.pw_gecos = NULL;
  passwd_cache.pw_dir = NULL;
  passwd_cache.pw_shell = NULL;
}

/* Event handlers
 */

static void auth_cdb_restart_ev(const void *event_data, void *user_data) {
  cdb_clear_passwd_cache();
  cdb_clear_group_cache();
}

/* initialize the module by registering the rehash function, allocating
 * pools.
 */
static int auth_cdb_init(void) {
  passwd_pool = make_sub_pool(permanent_pool);
  group_pool = make_sub_pool(permanent_pool);

  cdb_clear_passwd_cache();
  cdb_clear_group_cache();

  pr_event_register(&auth_cdb_module, "core.restart", auth_cdb_restart_ev,
    NULL);

  /* make sure the cdb structures are marked as "uninitialized" */
  group_cdb.fd = -1;
  group_cdb.mtime = (time_t) 0;
  passwd_cdb.fd = -1;
  passwd_cdb.mtime = (time_t) 0;

  return 0;
}

/* Authentication handlers
 */

/* cmd->argv[0]: user name
 * cmd->argv[1]: cleartext password
 */

MODRET cdb_auth(cmd_rec *cmd) {
  time_t now;

  /* unless mod_auth's order of calling authtab functions changes, I'm
   * going to assume that the cached passwd information is not stale, and
   * save myself the trouble of some function calls here
   */
  char *cryptpw = passwd_cache.pw_passwd;

  /* NOTE: these variables will be largely unused until this module
   *  provides quasi-shadowing support
   */
  time_t lstchg = -1, max = -1, inact = -1, disable = -1;

  /* make sure we have a passwd to work with
   */
  if (!cryptpw)
    return PR_DECLINED(cmd);

  time(&now);

  if (!cryptpw)
    return PR_ERROR_INT(cmd, PR_AUTH_NOPWD);

  if (pr_auth_check(cmd->tmp_pool, cryptpw, cmd->argv[0], cmd->argv[1])) {
    return PR_ERROR_INT(cmd, PR_AUTH_BADPWD);
  }

  if (lstchg > (time_t) 0 &&
      max > (time_t) 0 &&
      inact > (time_t) 0)
    if (now > lstchg + max + inact)
      return PR_ERROR_INT(cmd, PR_AUTH_AGEPWD);

  if (disable > (time_t) 0 &&
      now > disable)
    return PR_ERROR_INT(cmd, PR_AUTH_DISABLEDPWD);

  return PR_HANDLED(cmd);
}

/* cmd->argv[0] = hashed password
 * cmd->argv[1] = user name
 * cmd->argv[2] = cleartext password
 */
MODRET cdb_check(cmd_rec *cmd) {
  char *cryptpw = cmd->argv[0];
  char *clearpw = cmd->argv[2];

  if (strcmp(crypt(clearpw, cryptpw), cryptpw) != 0) {
    pr_log_debug(DEBUG0, MOD_AUTH_CDB_VERSION
      ": unable to check password, declining");
    return PR_DECLINED(cmd);
  }

  return PR_HANDLED(cmd);
}

MODRET cdb_name2uid(cmd_rec *cmd) {

  /* if the requested user's information is already in the cached struct
   * passwd, return that.  Only if the requested user is different should a
   * lookup be done.
   */
  if (passwd_cache.pw_name &&
      !strcmp(passwd_cache.pw_name, cmd->argv[0]))
    return mod_create_data(cmd, (void *) passwd_cache.pw_uid);

  if (cdb_get_passwd(cmd->argv[0]) != NULL)
    return mod_create_data(cmd, (void *) passwd_cache.pw_uid);

  return PR_DECLINED(cmd);
}

MODRET cdb_name2gid(cmd_rec *cmd) {

  /* if the requested group's information is already in the cached struct
   * group, return that.  Only if the requested group is different should a
   * lookup be done.
   */
  if (group_cache.gr_name &&
      !strcmp(group_cache.gr_name, cmd->argv[0]))
    return mod_create_data(cmd, (void *) group_cache.gr_gid);

  if (cdb_get_group(cmd->argv[0]) != NULL)
    return mod_create_data(cmd, (void *) group_cache.gr_gid);

  return PR_DECLINED(cmd);
}

MODRET cdb_uid2name(cmd_rec *cmd) {
  char buf[PR_CDB_BUFFER_SIZE] = {'\0'};

  /* if the requested user's information is already in the cached struct
   * passwd, return that.  Only if the requested user is different should a
   * lookup be done.
   */
  if (passwd_cache.pw_uid &&
      passwd_cache.pw_uid == (uid_t) cmd->argv[0])
    return mod_create_data(cmd, (void *) passwd_cache.pw_name);

  /* convert the given numeric into a string */
  snprintf(buf, sizeof(buf), "%lu", (unsigned long) cmd->argv[0]);
  if (cdb_get_passwd(buf) != NULL)
    return mod_create_data(cmd, (void *) passwd_cache.pw_name);

  return PR_DECLINED(cmd);
}

MODRET cdb_gid2name(cmd_rec *cmd) {
  char buf[PR_CDB_BUFFER_SIZE] = {'\0'};

  /* if the requested group's information is already in the cached struct
   * group, return that.  Only if the requested group is different should a
   * lookup be done.
   */
  if (group_cache.gr_gid &&
      group_cache.gr_gid == (gid_t) cmd->argv[0])
    return mod_create_data(cmd, (void *) group_cache.gr_name);

  /* convert the given numeric into a string */
  snprintf(buf, sizeof(buf), "%lu", (unsigned long) cmd->argv[0]);
  if (cdb_get_group(buf) != NULL)
    return mod_create_data(cmd, (void *) group_cache.gr_name);

  return PR_DECLINED(cmd);
}

MODRET cdb_endgrent(cmd_rec *cmd) {
  cdb_close_group();
  return PR_DECLINED(cmd);
}

MODRET cdb_getgrnam(cmd_rec *cmd) {
  if (!cdb_open_group())
    return PR_DECLINED(cmd);

  /* if the requested group's information is already in the group cache,
   * return that.  Only if the requested group is different should a lookup
   * be done.
   */
  if (group_cache.gr_name &&
      !strcmp(group_cache.gr_name, cmd->argv[0]))
    return mod_create_data(cmd, (void *) &group_cache);

  if (cdb_get_group(cmd->argv[0]) != NULL)
    return mod_create_data(cmd, (void *) &group_cache);

  return PR_DECLINED(cmd);
}

MODRET cdb_getgrent(cmd_rec *cmd) {
  if (!cdb_open_group())
    return PR_DECLINED(cmd);

  /* NOTE: this function may not be necessary, as the CDB format means that
   * lookups don't need to scroll through every record.  However, it should
   * probably be implemented at some point anyway, should some module
   * require the ability to iterate through group/passwd structs.
   */
  return PR_HANDLED(cmd);
}

MODRET cdb_getgrgid(cmd_rec *cmd) {
  char buf[PR_CDB_BUFFER_SIZE] = {'\0'};

  if (!cdb_open_group())
    return PR_DECLINED(cmd);
  
  /* if the requested group's information is already in the group cache,
   * return that.  Only if the requested group is different should a lookup
   * be done.
   */
  if (group_cache.gr_gid != (gid_t) -1 &&
      group_cache.gr_gid == (gid_t) cmd->argv[0])
    return mod_create_data(cmd, (void *) &group_cache);
  
  /* convert the given numeric into a string */
  snprintf(buf, sizeof(buf), "%lu", (unsigned long) cmd->argv[0]);
  if (cdb_get_group(buf) != NULL)
    return mod_create_data(cmd, (void *) &group_cache);

  return PR_DECLINED(cmd);
}

MODRET cdb_setgrent(cmd_rec *cmd) {
  cdb_rewind(&group_cdb);
  return PR_DECLINED(cmd);
}

MODRET cdb_endpwent(cmd_rec *cmd) {
  cdb_close_passwd();
  return PR_DECLINED(cmd);
}

MODRET cdb_getpwnam(cmd_rec *cmd) {

  if (!cdb_open_passwd())
    return PR_DECLINED(cmd);

  /* if the requested user's information is already in the passwd cache,
   * return that.  Only if the requested user is different should a lookup
   * be done
   */
  if (passwd_cache.pw_name &&
      !strcmp(passwd_cache.pw_name, cmd->argv[0]))
    return mod_create_data(cmd, (void *) &passwd_cache);

  if (cdb_get_passwd(cmd->argv[0]) != NULL)
    return mod_create_data(cmd, (void *) &passwd_cache);

  return PR_DECLINED(cmd);
}

MODRET cdb_getpwent(cmd_rec *cmd) {
  if (!cdb_open_passwd())
    return PR_DECLINED(cmd);

  /* rewind to the start of the passwd cdb, and start scrolling through
   * the records
   */

  /* NOTE: this function may not be necessary, as the CDB format means that
   * lookups don't need to scroll through every record.  However, it should
   * probably be implemented at some point anyway, should some module
   * require the ability to iterate through group/passwd structs.
   */

  return PR_HANDLED(cmd);
}

MODRET cdb_getpwuid(cmd_rec *cmd) {
  char buf[PR_TUNABLE_BUFFER_SIZE] = {'\0'};

  if (!cdb_open_passwd())
    return PR_DECLINED(cmd);
  
  /* if the requested user's information is already in the passwd cache,
   * return that.  Only if the requested user is different should a lookup
   * be done.
   */
  if (passwd_cache.pw_uid != (uid_t) -1 &&
      passwd_cache.pw_uid == (uid_t) cmd->argv[0])
    return mod_create_data(cmd, (void *) &passwd_cache);
 
  /* convert the given numeric into a string */
  snprintf(buf, sizeof(buf), "%lu", (unsigned long) cmd->argv[0]);
  if (cdb_get_passwd(buf) != NULL)
    return mod_create_data(cmd, (void *) &passwd_cache);
 
  return PR_DECLINED(cmd);
}

MODRET cdb_setpwent(cmd_rec *cmd) {
  cdb_rewind(&passwd_cdb);
  return PR_DECLINED(cmd);
}

/* Configuration directive handlers
 */

MODRET set_authcdbgroupfile(cmd_rec *cmd) {
  CHECK_ARGS(cmd, 1);
  CHECK_CONF(cmd, CONF_ROOT|CONF_VIRTUAL|CONF_GLOBAL);

  /* insure that an absolute path has been given */
  if (*(cmd->argv[1]) != '/')
    CONF_ERROR(cmd, "requires an absolute path");

  add_config_param_str("AuthCDBGroupFile", 1, (void *) cmd->argv[1]);
  return PR_HANDLED(cmd);
}

MODRET set_authcdbuserfile(cmd_rec *cmd) {
  CHECK_ARGS(cmd, 1);
  CHECK_CONF(cmd, CONF_ROOT|CONF_VIRTUAL|CONF_GLOBAL);

  /* insure that an absolute path has been given */
  if (*(cmd->argv[1]) != '/')
    CONF_ERROR(cmd, "requires an absolute path");

  add_config_param_str("AuthCDBUserFile", 1, (void *) cmd->argv[1]);
  return PR_HANDLED(cmd);
}

/* ProFTPD Module API tables
 */

static conftable auth_cdb_conftab[] = {
  { "AuthCDBGroupFile", set_authcdbgroupfile, NULL },
  { "AuthCDBUserFile", set_authcdbuserfile, NULL },
  { NULL }
};

static authtable auth_cdb_authtab[] = {
  { 0, "setpwent",  cdb_setpwent },
  { 0, "setgrent",  cdb_setgrent },
  { 0, "endpwent",  cdb_endpwent },
  { 0, "endgrent",  cdb_endgrent },
  { 0, "getpwent",  cdb_getpwent },
  { 0, "getgrent",  cdb_getgrent },
  { 0, "getpwnam",  cdb_getpwnam },
  { 0, "getgrnam",  cdb_getgrnam },
  { 0, "getpwuid",  cdb_getpwuid },
  { 0, "getgrgid",  cdb_getgrgid },
  { 0, "auth",      cdb_auth     },
  { 0, "check",     cdb_check    },
  { 0, "uid_name",  cdb_uid2name },
  { 0, "gid_name",  cdb_gid2name },
  { 0, "name_uid",  cdb_name2uid },
  { 0, "name_gid",  cdb_name2gid },
  { 0, NULL }
};

module auth_cdb_module = {
  NULL,
  NULL,

  /* Module API version 2.0 */
  0x20,

  /* Module name */
  "auth_cdb",

  /* Module configuration handler table */
  auth_cdb_conftab,

  /* Module command handler table */
  NULL,

  /* Module authentication handler table */
  auth_cdb_authtab,

  /* Module initialization function */
  auth_cdb_init,

  /* Module session initialization function */
  NULL,

  /* Module version */
  MOD_AUTH_CDB_VERSION
};
