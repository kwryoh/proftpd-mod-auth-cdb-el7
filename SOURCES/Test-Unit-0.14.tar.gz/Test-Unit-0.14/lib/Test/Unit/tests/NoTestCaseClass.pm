package Test::Unit::tests::NoTestCaseClass;
use strict;

sub new {
}

sub testSuccess {
}

1;
