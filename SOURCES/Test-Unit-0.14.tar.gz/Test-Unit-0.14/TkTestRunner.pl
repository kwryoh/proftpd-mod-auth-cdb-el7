use Test::Unit::TkTestRunner;
Test::Unit::TkTestRunner::main(@ARGV);


